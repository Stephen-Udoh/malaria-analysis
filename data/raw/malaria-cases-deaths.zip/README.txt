GLOBAL HEALTH OBSERVATORY DOWNLOAD
====================================
This zip data file has been downloaded from 

	Name: Malaria burden data: cases and deaths
	URL: https://www.who.int/data/gho/data/themes/topics/topic-details/GHO/malaria-cases-deaths
	Description: 
	 Malaria transmission occurs in 80 countries across five WHO regions. Since 2015, the WHO European Region has been free of malaria.According to the
World Malaria Report 2025 , there were 282 million estimated cases of malaria globally in 2024, with an incidence of 64 cases per 1000 population at risk. This is an increase of 9 million cases from the previous year and a rise in incidence from 62.7 cases per 1000 population at risk in 2023. Globally, in 2024, the number of deaths was estimated at 610 000, with a mortality rate of 13.8 per 100 000 population at risk. The WHO African Region continues to carry the heaviest burden of malaria, accounting for an estimated 94% of malaria cases and 95% of malaria deaths worldwide in 2024; 75% of all deaths in this region were among children aged under 5 years old.  Source: WMR2025
	
	Date generated: 2026-01-06

It contains csv files divided into two folders: data and codes

	data: contains one csv file per indicator under "Malaria burden data: cases and deaths"
	
	codes: contains one csv file per disaggregation/dimension used in the data files
	


Hierarchy

	parent: malaria
	self: malaria-cases-deaths
	children: 
		MALARIA_TOTAL_CASES	Malaria cases (presumed + confirmed cases), total, number
		MALARIA_CONF_CASES	Malaria cases, confirmed, number
		GHO	Malaria cases, imported, number
		MALARIA_IMPORTED	Malaria cases, imported, number
		MALARIA_INDIG	Malaria cases, indigenous, number
		MALARIA002	Malaria cases, number, estimate
		MALARIA_PF_INDIG	Malaria cases, P. falciparum, indigenous, number
		MALARIA_PV_INDIG	Malaria cases, P. vivax, indigenous, number
		MALARIA_PRES_CASES	Malaria cases, presumed, number
		MALARIA003	Malaria deaths, number, estimate
		MALARIA_EST_INCIDENCE	Malaria incidence (per 1000 population at risk), estimate
		MALARIA_EST_MORTALITY	Malaria mortality rate (per 100 000 population), estimate
	
