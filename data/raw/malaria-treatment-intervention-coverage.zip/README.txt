GLOBAL HEALTH OBSERVATORY DOWNLOAD
====================================
This zip data file has been downloaded from 

	Name: Malaria treatment and intervention coverage
	URL: https://www.who.int/data/gho/data/themes/topics/topic-details/GHO/malaria-treatment-intervention-coverage
	Description: 
	 Malaria transmission occurs in 80 countries across five WHO regions. Since 2015, the WHO European Region has been free of malaria.According to the
World Malaria Report 2025 , there were 282 million estimated cases of malaria globally in 2024, with an incidence of 64 cases per 1000 population at risk. This is an increase of 9 million cases from the previous year and a rise in incidence from 62.7 cases per 1000 population at risk in 2023. Globally, in 2024, the number of deaths was estimated at 610 000, with a mortality rate of 13.8 per 100 000 population at risk. The WHO African Region continues to carry the heaviest burden of malaria, accounting for an estimated 94% of malaria cases and 95% of malaria deaths worldwide in 2024; 75% of all deaths in this region were among children aged under 5 years old.  Source: WMR2025
	
	Date generated: 2026-01-06

It contains csv files divided into two folders: data and codes

	data: contains one csv file per indicator under "Malaria treatment and intervention coverage"
	
	codes: contains one csv file per disaggregation/dimension used in the data files
	


Hierarchy

	parent: malaria
	self: malaria-treatment-intervention-coverage
	children: 
		GHO	Malaria cases treated with artemisinin-based combination therapies (ACTs), number
		MALARIA_ACT_TREATED	Malaria cases treated with artemisinin-based combination therapies (ACTs), number
		MALARIA_IRS_COVERAGE	Malaria protection, people protected from malaria by indoor residual spraying (IRS), number
		MALARIA_ITN_COVERAGE	Malaria protection: insecticide-treated bed net (ITN) , population with access (%), modelled
		MALARIA_IPTP3_COVERAGE	Malaria treatment IPTp3: pregnant women attending antenatal care at least once and receiving at least 3 doses of Intermittent Preventive Treatment of Malaria for Pregnant Women (IPTp3) (%)
		MALARIA_1STLINE_TREATED	Malaria treatment, cases treated with any first  line tx courses (including artemisinin-based combination therapies (ACTs)), number
	
